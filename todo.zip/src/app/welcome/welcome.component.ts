import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  constructor(private router: ActivatedRoute) { }

  username: string;

  ngOnInit() {
    console.log(this.router);
    if (!this.router || !this.router.snapshot) {
      return null;
    } else {
      if (this.router.snapshot.params['username']) {
        this.username = this.router.snapshot.params['username'];
      }
    }
  }

}
