import { Component, OnInit } from '@angular/core';
import { Todo } from '../app.module.shared';
import { Location } from '@angular/common';

@Component({
  selector: 'app-listTodo',
  templateUrl: './listTodo.component.html',
  styleUrls: ['./listTodo.component.css']
})
export class ListTodoComponent implements OnInit {
  todoList: any;
  // todoList = [{id: 1, desc: 'learn Angular'}, {id: 2, desc: 'learn Material'}, {id: 3, desc: 'learn webdesign'}];
  constructor(private location: Location) {
    this.todoList = [new Todo(1, "Study Angular", new Date(), true),
    new Todo(2, "Visit Italy", new Date(), false),
    new Todo(3, "Talk to mom", new Date(), false)];
  }

  ngOnInit() {
    console.log('location', location);
  }

}
