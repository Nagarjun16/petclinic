import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './utility/login/login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ListTodoComponent } from './listTodo/listTodo.component';

const routes: Routes = [
  {path: 'util', loadChildren: './utility/utility.module#UtilityModule'},
  {path: 'welcome/:username', component: WelcomeComponent},
  {path: 'todo', component: ListTodoComponent},
  {path: '**', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
