import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template: '<h1>{{title}}</h1> <br> <body>{{message}}</body>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  // title = 'todo';
  // message = 'Hello Bi chalta hai';
}
