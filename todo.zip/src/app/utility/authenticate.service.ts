import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

constructor() { }

public checkAuthentication(username: string, password: string): boolean {
  if (password === 'password') {
    return true;
  }
  return false;
}

}
