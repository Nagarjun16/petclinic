import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticateService } from './../authenticate.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username: string;
  password: string;
  isValidLogin: boolean;
  invalidLoginError: string;

  constructor(private router: Router, private authenticateService: AuthenticateService) { }

  ngOnInit() {
    console.log('Inside login component');
    this.isValidLogin = true;
  }

  performLogin() {
    if (this.authenticateService.checkAuthentication(this.username, this.password)) {
      this.isValidLogin = true;
      this.router.navigate(['/welcome', this.username]);
    } else {
      this.isValidLogin = false;
    }
    console.log('Username:' + this.username + ' password:' + this.password);
  }

}
